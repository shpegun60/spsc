#ifndef TYPED_POOL_TEST_H
#define TYPED_POOL_TEST_H

void run_tst_typed_pool_api_paranoid(int argc, char** argv);


#endif // TYPED_POOL_TEST_H
