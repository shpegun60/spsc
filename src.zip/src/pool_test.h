#ifndef POOL_TEST_H_
#define POOL_TEST_H_

void run_tst_pool_api_paranoid(bool verbose);

#endif /* POOL_TEST_H_ */
