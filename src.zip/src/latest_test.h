#ifndef LATEST_TEST_H
#define LATEST_TEST_H

int run_tst_latest_api_paranoid(int argc, char** argv);

#endif // LATEST_TEST_H
