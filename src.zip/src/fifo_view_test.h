#ifndef FIFO_VIEW_TEST_H_
#define FIFO_VIEW_TEST_H_

int run_tst_fifo_view_api_paranoid(int argc, char** argv);

#endif /* FIFO_VIEW_TEST_H_ */
