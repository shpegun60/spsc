#ifndef POOL_VIEW_TEST_H
#define POOL_VIEW_TEST_H

int run_tst_pool_view_api_paranoid(int argc, char** argv);

#endif // POOL_VIEW_TEST_H
