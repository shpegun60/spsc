#ifndef FIFO_BENCH_H
#define FIFO_BENCH_H

// Console-style benchmark runner for spsc::fifo.
// Returns 0 on success.
int run_fifo_bench();

#endif // FIFO_BENCH_H
